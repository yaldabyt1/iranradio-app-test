import React, { useMemo } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useGetPodcastDetailBySlugQuery } from "../services/iranradioApi";
import { setQueue, setCurrentIndex } from "../slice/playerSlice";
import { toggleListenLaterLocal } from "../slice/listenLaterSlice";

const EMPTY_EPISODES = [];

export default function ShowPage() {
  const { podcastSlug } = useParams(); // route: /podcast/:podcastSlug
  const dispatch = useDispatch();

  const { data, isLoading, isError, error } = useGetPodcastDetailBySlugQuery(podcastSlug);
  const listenLaterIds = useSelector((s) => (s.listenLater?.ids || []).map(String));

  const show = data?.podcast;
  const episodes = data?.episodes ?? EMPTY_EPISODES;

  const queue = useMemo(() => episodes.map(mapEpisodeToPlayer), [episodes]);

  const handlePlayShow = () => {
    if (!queue.length) return;
    dispatch(setQueue(queue));
    dispatch(setCurrentIndex(0));
  };

  const handlePlayEpisode = (idx) => {
    dispatch(setQueue(queue));
    dispatch(setCurrentIndex(idx));
  };

  const onToggleSave = (episodeId) => dispatch(toggleListenLaterLocal(String(episodeId)));

  if (isLoading) {
    return (
      <div className="col-12 col-md-9 offset-md-3 mainPage text-white">
        <Container className="py-5">
          <h2>Loading...</h2>
        </Container>
      </div>
    );
  }

  if (isError || !show) {
    return (
      <div className="col-12 col-md-9 offset-md-3 mainPage text-white">
        <Container className="py-5">
          <h2>Failed</h2>
          <p style={{ opacity: 0.8 }}>{String(error?.data || error?.error || error)}</p>
        </Container>
      </div>
    );
  }

  return (
    <div className="col-12 col-md-9 offset-md-3 mainPage">
      <Container className="py-5 text-white">
        <Row>
          <Col md={3} className="pt-3 text-center">
            <Card className="bg-dark text-white border-0">
              <Card.Img src={show.cover || ""} alt={stripHtml(show.title)} />
              <div className="mt-4 text-center">
                <p className="album-title" style={{ fontWeight: 700 }}>
                  {stripHtml(show.title)}
                </p>
              </div>

              <div className="mt-3 text-center">
                <Button variant="success" onClick={handlePlayShow} disabled={!queue.length}>
                  Play
                </Button>
              </div>
            </Card>
          </Col>

          <Col md={8} className="p-3 p-md-5">
            <h4 className="mb-4">Episodes</h4>

            {episodes.length === 0 ? (
              <p className="text-white-50">No episodes yet.</p>
            ) : (
              <div className="d-flex flex-column gap-2">
                {episodes.map((ep, idx) => {
                  const id = String(ep.id);
                  const isSaved = listenLaterIds.includes(id);

                  return (
                    <div
                      key={id}
                      className="d-flex justify-content-between align-items-center p-3 rounded"
                      style={{ background: "rgba(255,255,255,0.06)" }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {idx + 1}. {stripHtml(ep.title)}
                        </div>
                      </div>

                      <div className="d-flex align-items-center gap-3">
                        <Button size="sm" variant="outline-light" onClick={() => handlePlayEpisode(idx)}>
                          Play
                        </Button>

                        <button
                          type="button"
                          className="btn btn-link p-0 text-decoration-none text-white"
                          title={isSaved ? "Unsave" : "Save"}
                          onClick={() => onToggleSave(id)}
                          aria-pressed={isSaved}
                          aria-label={isSaved ? "Remove from Listen Later" : "Save to Listen Later"}
                          style={{ fontSize: 18, lineHeight: 1 }}
                        >
                          {isSaved ? <i className="bi bi-bookmark-fill" /> : <i className="bi bi-bookmark" />}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Col>
        </Row>
      </Container>
    </div>
  );
}

function mapEpisodeToPlayer(ep) {
  return {
    id: String(ep.id),
    title: stripHtml(ep.title),
    showId: String(ep.podcastId),
    showTitle: stripHtml(ep.podcastTitle || ""),
    audioUrl: ep.audioUrl || "",
  };
}

function stripHtml(s) {
  if (!s) return "";
  return String(s).replace(/<[^>]*>/g, "").trim();
}