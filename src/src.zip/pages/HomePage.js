import React from "react";
import { Container } from "react-bootstrap";
import { Link } from "react-router-dom";
import {
  useGetPodcastCategoriesQuery,
  useGetPodcastsByCategoryIdQuery,
} from "../services/iranradioApi";
import { stripHtml } from "../shared/mappers/iranradio";

export default function HomePage() {
  const { data: categories = [], isLoading, isError, error } = useGetPodcastCategoriesQuery();

  if (isLoading) return <div className="text-white p-4">Loading...</div>;
  if (isError) return <div className="text-white p-4">Failed: {String(error?.error || error)}</div>;

  const topCats = categories.slice(0, 6);

  return (
    <div className="col-12 col-md-9 offset-md-3 mainPage text-white">
      <Container className="py-4">
        {topCats.map((cat) => (
          <CategoryRow key={cat.id} category={cat} />
        ))}
      </Container>
    </div>
  );
}

function CategoryRow({ category }) {
  const { data: podcasts = [], isLoading, isError } = useGetPodcastsByCategoryIdQuery({
    categoryId: category.id,
    page: 1,
    perPage: 12,
  });

  return (
    <div className="mb-4">
      <div className="d-flex justify-content-between align-items-center mb-2">
        <h5 className="m-0">{stripHtml(category.name)}</h5>

        <Link className="text-white-50" to={`/category/${category.slug}`}>
          See all
        </Link>
      </div>

      {isLoading ? (
        <div className="text-white-50">Loading…</div>
      ) : isError ? (
        <div className="text-danger">Failed loading podcasts</div>
      ) : podcasts.length === 0 ? (
        <div className="text-white-50">No podcasts</div>
      ) : (
        <div className="d-flex flex-column gap-2">
          {podcasts.slice(0, 6).map((p) => (
            <Link
              key={p.id}
              to={`/podcast/${p.slug}`}
              className="text-white text-decoration-none p-3 rounded"
              style={{ background: "rgba(255,255,255,0.06)" }}
            >
              {stripHtml(p.title)}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}